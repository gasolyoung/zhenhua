#!/bin/bash   
cd $LGSVL_SIM_DIR_PATH
./simulator