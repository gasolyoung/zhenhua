^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package vehicle_gazebo_simulation_interface
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.0 (2019-03-21)
-------------------
* cosmetic change
* update for can odometry
* fixed bug and typo
* publish tf and twist from gazebo
* subscribe autoware_msgs::VehicleCmd message
* cosmetic change
* Update ros/src/simulation/gazebo_simulator/vehicle/vehicle_gazebo_simulation_interface/package.xml
  Co-Authored-By: yukkysaito <yukky.saito@gmail.com>
* add comment for vehicle_gazebo_input_subscriber
* fixed bug (vehicle_gazebo_input_subscriber)
* initial commit gazebo simulator
* Contributors: Akihito Ohsato, Yukihiro SAITO
