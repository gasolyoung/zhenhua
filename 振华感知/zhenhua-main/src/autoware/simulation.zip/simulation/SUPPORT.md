# Support

For detailed instructions on getting help, see the [support guidelines](https://github.com/Autoware-AI/autoware.ai/wiki/Support-guidelines).
