# core_planning

![Native CI workflow](https://github.com/Autoware-AI/core_planning/workflows/Native%20CI%20workflow/badge.svg) ![CUDA CI workflow](https://github.com/Autoware-AI/core_planning/workflows/CUDA%20CI%20workflow/badge.svg) ![Cross CI workflow](https://github.com/Autoware-AI/core_planning/workflows/Cross%20CI%20workflow/badge.svg)

Autoware packages for planning the route and motion of a self-driving vehicle.

www.autoware.org
